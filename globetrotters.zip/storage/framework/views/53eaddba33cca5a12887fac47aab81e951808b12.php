<footer class="footer-area">
    <div class="container">
        <div class="row d-flex justify-content-between">
            <p class="col-sm-12 footer-text m-0 text-white text-center">
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
        </div>
    </div>
</footer>	<?php /**PATH D:\work\max_painter\globetrotters\resources\views/partials/footer.blade.php ENDPATH**/ ?>