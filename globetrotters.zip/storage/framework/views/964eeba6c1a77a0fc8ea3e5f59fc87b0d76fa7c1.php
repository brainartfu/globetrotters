<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <meta name="author" content="codepixer">
    <meta charset="UTF-8">
    <title><?php echo e(trans('panel.site_title')); ?></title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/linearicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>

<body>
    

    

    <?php echo $__env->yieldContent('home'); ?>

    <!-- Start post Area -->
    
    <!-- End post Area -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/vendor/jquery-2.2.4.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/hoverIntent.js')); ?>"></script>
    <script src="<?php echo e(asset('js/superfish.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.ajaxchimp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.sticky.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mail-script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/verlet/verlet-1.0.0.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <script>
        let csrfToken = "<?php echo e(csrf_token()); ?>";
        let APP_URL = "<?php echo e(env('APP_URL')); ?>";
        let areaId = "<?php echo e($areaId); ?>" * 1;
        let initLat = "<?php echo e($initLat); ?>" * 1;
        let initLng = "<?php echo e($initLng); ?>" * 1;
        let initZoom = "<?php echo e($initZoom); ?>" * 1;
        let postTotalCount = 0;
        let pageNum = 1;
        let pageViewCount = 5;
        let loggedUserId = "<?php echo e(Auth::user() ? Auth::user()->id : '0'); ?>";
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/map.js')); ?>"></script>
    <script src="<?php echo e(asset('js/blog.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel.js')); ?>"></script>
    <script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDcXJhC1bhN3aFXzRZqLrVYimIaxz60sgg&callback=initMap&v=beta&map_ids=ed1309c122a3dfcb&libraries=places"></script>
    
</body>

</html><?php /**PATH D:\work\max_painter\globetrotters\resources\views/layouts/home.blade.php ENDPATH**/ ?>