<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.category.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.categories.update", [$category->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('pid') ? 'has-error' : ''); ?>">
                <label for="name">Parent* </label>
                <select name="pid" id="pid" class="form-control">
                    <option value="0" <?php echo e($category->pid === "0" ? "selected" : ""); ?>>Top level</option>
                    <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parentCategory->id); ?>" <?php echo e($parentCategory->id === $category->pid ? "selected" : ""); ?>><?php echo e($parentCategory->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.category.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e($category->name); ?>" required>
                <?php if($errors->has('name')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('name')); ?>

                </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.category.fields.name_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\max_painter\globetrotters\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>