<?php

return [
    'site_title' => 'Globetrotters',
];
