let map = null;
let placeService = null;
let placeTypes = [];
let currPlace = null;
let markers = [];

const locationInfo = [
  'country',
  'administrative_area_level_1',
  'administrative_area_level_2',
  'administrative_area_level_3',
  'administrative_area_level_4',
  'administrative_area_level_5',
  'locality'
];

initMap = () => {
  // 
  map = new google.maps.Map(document.getElementById('map'), {
    center: new google.maps.LatLng(initLat, initLng),
    zoom: initZoom,
    gestureHandling: 'greedy',
    streetViewControl: false,
    mapTypeControl: true,
    mapTypeControlOptions: {
      style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
      position: google.maps.ControlPosition.TOP_CENTER
    },
    fullscreenControl: false,
    mapId: "ed1309c122a3dfcb",
    useStaticMap: false,
  });

  placeService = new google.maps.places.PlacesService(map);

  map.addListener('click', (mapsMouseEvent) => {
    if (mapsMouseEvent.placeId) {
      placeService.getDetails({
        placeId: mapsMouseEvent.placeId,
        // fields: ['name', 'rating', 'formatted_phone_number', 'geometry']
      }, function (place, status) {
        if (status == google.maps.places.PlacesServiceStatus.OK) {
          $('.post-group').scrollTop(0)
          map.fitBounds(place.geometry.viewport);

          let uri = [];
          for (let i = 0; i < place.address_components.length; i++) {
            locationInfo.forEach(area => {
              if (place.address_components[i].types[0] === area) {
                uri.push(place.address_components[i].short_name);
              }
            });
            if (uri.length === 2) break;
          }
          uri = uri.reverse().join('/');
          uri = uri.toLowerCase();
          uri = uri.replace(/ /g, "-");
          uri = uri.replace(/'/g, "");
          window.history.replaceState("", "Globetrotters", `${APP_URL}en/${uri}/category/post`);

          // saving data.
          let data = {};
          locationInfo.forEach(function (addressType) {
            place.address_components.forEach(function (item) {
              if (item['types'][0] == addressType) {
                data[addressType] = item['long_name'];
              }
            });
          });
          data['url'] = uri;
          data['lat'] = place.geometry.location.lat();
          data['lng'] = place.geometry.location.lng();
          data['zoom'] = map.getZoom();
          data['formatted_address'] = place.formatted_address;
          data['_token'] = csrfToken;

          $.ajax({
            url: APP_URL + 'areas/save',
            method: 'POST',
            data: data,
            success: (response) => {
              getPostInfo(response.response);
            }
          });
          currPlace = place;
          searchPlaces();
        }
      });
    }
  });
  map.addListener('drag', (mapsMouseEvent) => {
    drawRopes();
  });
  map.addListener('zoom_changed', (mapsMouseEvent) => {
    drawRopes();
  });
  map.addListener('dragend', (mapsMouseEvent) => {
    drawRopes();
  });
  map.addListener('idle', (mapsMouseEvent) => {
    drawRopes();
  });
}

const getPostInfo = id => {
  $('.post-content .title').text('');
  $('.post-content .content').html('');
  $('.view-count').text('0');
  $('.like-count').text('0');
  $('.dislike-count').text('0');

  $.ajax({
    url: `${APP_URL}blog/${id}`,
    method: 'GET',
    data: {
      pageNum: 1,
      pageViewCount
    },
    success: res => {
      pageNum = 1;
      let htmlStr = ``;

      res.forEach(post => {
        let categoriesStr = ``;
        post.categories &&
          post.categories.forEach(item => {
            categoriesStr += `<span class="btn btn-white btn-sm text-secondary"><i class="fa fa-tag"></i> ${item}</span>`;
          });

        let postStr = `
          <div class="post pb-5 border-top">
            <div class="post-header d-flex justify-content-between py-2">
              <div class="d-flex align-items-center">
                <img src="${APP_URL}img/users/10.jfif" class="avatar">
                <p class="mb-0 categories d-flex">${categoriesStr}</p>
              </div>
              <div class="d-flex post-status">
                <a class="view-count btn btn-sm text-secondary d-flex align-items-center">
                  <i class="fa fa-eye fa-lg mr-1"></i>
                  <span class="count">${post.view_count}</span>
                </a>
                <a class="btn btn-sm text-secondary d-flex align-items-center" post-id="${post.id}" onClick="like(this)">
                  <i class="fa fa-thumbs-up fa-lg mr-1"></i>
                  <span class="count">${post.like_count}</span>
                </a>
                <a class="dislike-count btn btn-sm text-secondary d-flex align-items-center" post-id="${post.id}" onClick="dislike(this)">
                  <i class="fa fa-thumbs-down fa-lg mr-1"></i>
                  <span class="count">${post.dislike_count}</span>
                </a>
              </div>
            </div>
            <div class="post-content">
              <h3>${post.title}</h3>
              <div class="content">
                ${post.content}
                <li style='list-style-type: none' class='d-flex justify-content-between align-items-center'>
                  <h5>Comments</h5>
                  <button comment-id='0' post-id=${post.id} class='open-send-form btn mb-1 btn-primary btn-sm'>
                    Add Comment
                  </button>
                </li>
              </div>
              <div class="post-comments-container">
                <div class="comment-list">${getCommentsHtml(post.comments, post.id)}</div>
              </div>
            </div>
          </div>
        `;
        htmlStr += postStr;
      });
      $('.post-blog').html(htmlStr);
    }
  })
}

function searchPlaces() {
  placeService.nearbySearch({
    location: currPlace.geometry.location,
    // radius: '50000',
    rankBy: google.maps.places.RankBy.DISTANCE,
    type: placeTypes
  }, function (results, status) {
    if (status == google.maps.places.PlacesServiceStatus.OK) {
      for (var m in markers) {
        markers[m].setMap(null);
      }
      $('.place-photos').html('');
      markers = [];
      for (var address of results) {
        if (address.photos) {
          let html = '<div class="place-photo" title="' + address.name + '">';
          html += '<img src="' + address.photos[0].getUrl() + '" class="dot-img">';
          html += '<span class="place-photo-label">' + address.name + '</span>';
          html += '</div>';
          $('.place-photos').append(html).scrollTop(0);

          markers[markers.length] = new google.maps.Marker({
            position: address.geometry.location,
            map: map
          });
        }
      }
      drawRopes();
    }
  });
}

var sim;
var canvas;
var loop = function () {
  sim.frame(16);
  sim.draw();
  requestAnimFrame(loop);
};

window.onload = function () {
  initCanvas();
  loop();
};

function getPoints(sPoint, ePoint) {
  let points = [];
  let distance = 20;
  let hor = ePoint[0] - sPoint[0];
  let ver = ePoint[1] - sPoint[1];

  let segments = Math.sqrt(Math.pow(hor, 2) + Math.pow(ver, 2)) / distance;

  let h = sPoint[0], v = sPoint[1];
  for (var s = 0; s < segments - 1; s++) {
    h += hor / segments;
    v += ver / segments;
    points[s] = new Vec2(h, v);
  }
  points[s] = new Vec2(ePoint[0], ePoint[1]);
  return points;
}

function drawRope(sPoint, ePoint) {
  if (sPoint[0] > 1100 || sPoint[0] < 0) return false;
  if (sPoint[1] > 400 || sPoint[1] < 0) return false;
  if (ePoint[0] > 1100 || ePoint[0] < 0) return false;
  if (ePoint[1] > 400 || ePoint[1] < 0) return false;
  let points = getPoints(sPoint, ePoint);
  var segment = sim.lineSegments(points, 7);
  segment.pin(0);
  segment.pin(points.length - 1);
  return segment;
}

function drawRopes() {
  initCanvas();
  var scale = Math.pow(2, map.getZoom());
  var proj = map.getProjection();
  var bounds = map.getBounds();
  var nw = proj.fromLatLngToPoint(
    new google.maps.LatLng(
      bounds.getNorthEast().lat(),
      bounds.getSouthWest().lng()
    )
  );

  var point;
  var i = 0;
  $('.place-photo').each(function () {
    point = proj.fromLatLngToPoint(markers[i].position);
    sim.ctx.strokeStyle = "#ff0000";
    drawRope([145, $(this).offset().top + 50], [(point.x - nw.x) * scale, (point.y - nw.y) * scale])
    i++;
  });

}

function initCanvas() {
  canvas = document.getElementById("canvas");
  var width = parseInt($(canvas).width());
  var height = parseInt($(canvas).height());
  canvas.width = width;
  canvas.height = height;
  sim = new VerletJS(width, height, canvas);
}

function hideCanvas() {
  // $('#canvas').hide();
}

$('.place-photos').scroll(function () {
  drawRopes()
});


$('.category-list a').click(function(event) {
  event.preventDefault();
  $.ajax({
    url: `${APP_URL}admin/categories/get-categories-by-parent?pid=${$(this).attr('data-id')}`,
    method: 'GET',
    success: (res) => {
      let mapCategories = [];
      res.map((item) => {
        mapCategories.push(item.name);
      });
      placeTypes = mapCategories;
      searchPlaces();
    }
  });
});