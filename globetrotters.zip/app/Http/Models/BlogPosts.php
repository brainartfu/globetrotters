<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class BlogPosts extends Model
{
    protected $table = 'blog_posts';
    public $timestamps = false;
}
