<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class BlogPostTags extends Model
{
    protected $table = 'blog_post_tags';
}
