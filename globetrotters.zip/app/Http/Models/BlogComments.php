<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class BlogComments extends Model
{
    protected $table = 'blog_comments';
    public $timestamps = false;
}
