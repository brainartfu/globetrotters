<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class BlogPostCategories extends Model
{
    protected $table = 'blog_post_categories';
}
