<?php

namespace App\Http\Controllers;

use App\Http\Models\Category;
use App\Http\Models\Location;
use App\Http\Models\Job;
use App\Http\Models\Area;
use App\Http\Models\BlogCategories;
use App\Http\Models\BlogTags;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index($lang = 'en', $any = null, $category = 'category', $post = 'post')
    {
        $categories = Category::where('pid', '0')->get();
        $blogTags = BlogTags::all();
        $address = 'United Kingdom';
        $areaId = 0;
        $initLat = 51.51316578087706;
        $initLng = 0.2629141959194836;
        $initZoom = 4;
        $postInfo = [];

        $area = Area::where('url', $any)->first();

        if ($area) {
            $areaId = $area->id;
            $initLat = $area->lat;
            $initLng = $area->lng;
            $initZoom = $area->zoom;
        }

        $searchLocations = Location::pluck('name', 'id');
        $searchCategories = Category::pluck('name', 'id');
        $searchByCategory = Category::withCount('jobs')
            ->orderBy('jobs_count', 'desc')
            ->take(5)
            ->pluck('name', 'id');
        $jobs = Job::with('company')
            ->orderBy('id', 'desc')
            ->take(7)
            ->get();

        return view('index', compact([
            'searchLocations',
            'searchCategories',
            'searchByCategory',
            'jobs',
            'initLat',
            'initLng',
            'initZoom',
            'areaId',
            'categories',
            'blogTags',
            'postInfo'
        ]));
    }

    public function search(Request $request)
    {
        $jobs = Job::with('company')
            ->searchResults()
            ->paginate(7);

        $banner = 'Search results';

        return view('jobs.index', compact(['jobs', 'banner']));
    }
}
