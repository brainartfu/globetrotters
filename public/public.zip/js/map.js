let map = null;
let markers = [];

const locationInfo = [
  'country',
  'administrative_area_level_1',
  'administrative_area_level_2',
  'administrative_area_level_3',
  'administrative_area_level_4',
  'administrative_area_level_5',
  'locality'
];

initMap = () => {
  // 
  map = new google.maps.Map(document.getElementById('map'), {
    center: new google.maps.LatLng(initLat, initLng),
    zoom: initZoom,
    gestureHandling: 'greedy',
    streetViewControl: false,
    mapTypeControl: false,
    mapId: "ed1309c122a3dfcb",
    useStaticMap: false,
  });
  map.addListener('click', (mapsMouseEvent) => {
    let placeService = new google.maps.places.PlacesService(map);
    placeService.getDetails({
      placeId: mapsMouseEvent.placeId,
      // fields: ['name', 'rating', 'formatted_phone_number', 'geometry']
    }, function (place, status) {
      if (status == google.maps.places.PlacesServiceStatus.OK) {
        for (var a in place.photos) {
          // console.log(place.photos[a].getUrl())
        }
        $('.post-group').scrollTop(0)
        map.fitBounds(place.geometry.viewport);

        let uri = [];
        for (let i = 0; i < place.address_components.length; i++) {
          locationInfo.forEach(area => {
            if (place.address_components[i].types[0] === area) {
              uri.push(place.address_components[i].short_name);
            }
          });
          if (uri.length === 2) break;
        }
        uri = uri.reverse().join('/');
        uri = uri.toLowerCase();
        uri = uri.replace(/ /g, "-");
        uri = uri.replace(/'/g, "");
        window.history.replaceState("", "Globetrotters", `${APP_URL}en/${uri}/category/post`);

        // saving data.
        let data = {};
        locationInfo.forEach(function (addressType) {
          place.address_components.forEach(function (item) {
            if (item['types'][0] == addressType) {
              data[addressType] = item['long_name'];
            }
          });
        });
        data['url'] = uri;
        data['lat'] = place.geometry.location.lat();
        data['lng'] = place.geometry.location.lng();
        data['zoom'] = map.getZoom();
        data['formatted_address'] = place.formatted_address;
        data['_token'] = csrfToken;

        $.ajax({
          url: APP_URL + 'areas/save',
          method: 'POST',
          data: data,
          success: (response) => {
            getPostInfo(response.response);
          }
        });

        placeService.nearbySearch({
          location: place.geometry.location,
          radius: '50000',
          type: place.types
        }, function (results, status) {
          if (status == google.maps.places.PlacesServiceStatus.OK) {
            for (var m in markers) {
              markers[m].setMap(null);
            }
            $('.place-photos').html('');
            let html = '';
            for (var r in results) {
              if (results[r].photos) {
                html += '<div class="place-photo" title="' + results[r].name + '">';
                html += '<img src="' + results[r].photos[0].getUrl() + '" class="dot-img">';
                html += '<span class="place-photo-label">' + results[r].name + '</span>';
                html += '</div>';
                
                console.log(results[r])
                markers[markers.length] = new google.maps.Marker({
                  position: results[r].geometry.location,
                  map: map
                });
              }
            }
            $('.place-photos').append(html).scrollTop(0);
          }
        });
      }
    });
  });
}

const getPostInfo = id => {
  $('.post-content .title').text('');
  $('.post-content .content').html('');
  $('.view-count').text('0');
  $('.like-count').text('0');
  $('.dislike-count').text('0');

  $.ajax({
    url: `${APP_URL}blog/${id}`,
    method: 'GET',
    data: {
      pageNum: 1,
      pageViewCount
    },
    success: res => {
      pageNum = 1;
      let htmlStr = ``;

      res.forEach(post => {
        let categoriesStr = ``;
        post.categories &&
          post.categories.forEach(item => {
            categoriesStr += `<span class="btn btn-white btn-sm text-secondary"><i class="fa fa-tag"></i> ${item}</span>`;
          });

        let postStr = `
          <div class="post pb-5 border-top">
            <div class="post-header d-flex justify-content-between py-2">
              <div class="d-flex align-items-center">
                <img src="${APP_URL}img/users/10.jfif" class="avatar">
                <p class="mb-0 categories d-flex">${categoriesStr}</p>
              </div>
              <div class="d-flex post-status">
                <a class="view-count btn btn-sm text-secondary d-flex align-items-center">
                  <i class="fa fa-eye fa-lg mr-1"></i>
                  <span class="count">${post.view_count}</span>
                </a>
                <a class="btn btn-sm text-secondary d-flex align-items-center" post-id="${post.id}" onClick="like(this)">
                  <i class="fa fa-thumbs-up fa-lg mr-1"></i>
                  <span class="count">${post.like_count}</span>
                </a>
                <a class="dislike-count btn btn-sm text-secondary d-flex align-items-center" post-id="${post.id}" onClick="dislike(this)">
                  <i class="fa fa-thumbs-down fa-lg mr-1"></i>
                  <span class="count">${post.dislike_count}</span>
                </a>
              </div>
            </div>
            <div class="post-content">
              <h3>${post.title}</h3>
              <div class="content">
                ${post.content}
                <li style='list-style-type: none' class='d-flex justify-content-between align-items-center'>
                  <h5>Comments</h5>
                  <button comment-id='0' post-id=${post.id} class='open-send-form btn mb-1 btn-primary btn-sm'>
                    Add Comment
                  </button>
                </li>
              </div>
              <div class="post-comments-container">
                <div class="comment-list">${getCommentsHtml(post.comments, post.id)}</div>
              </div>
            </div>
          </div>
        `;
        htmlStr += postStr;
      });
      $('.post-blog').html(htmlStr);
    }
  })
}
